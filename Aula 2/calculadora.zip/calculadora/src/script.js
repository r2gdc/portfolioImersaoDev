var valor1 = parseFloat(prompt('Digitar o primeiro valor:'))

var operacao = prompt('Escolha a operação: / para divisão, * para multiplicação, + para somar ou - para subtrair')

var valor2 = parseFloat(prompt("Agora, digite o segundo valor:"))

if (operacao == "/") {
  var resultado = valor1/valor2
document.write("<h2>" + valor1 +" / "+ valor2 + " = " + resultado +'</h2>')
}

else if (operacao == "*") {
  var resultado = valor1*valor2
document.write("<h2>" + valor1 +" x "+ valor2 + " = " + resultado +'</h2>')
}

else if (operacao == "+") {
  var resultado = valor1+valor2
document.write("<h2>" + valor1 +" + "+ valor2 + " = " + resultado +'</h2>')
}

else if (operacao == "-") {
  var resultado = valor1-valor2
document.write("<h2>" + valor1 +" - "+ valor2 + " = " + resultado +'</h2>')
}

else  
document.write("<h2>" + 'ERRO' +'</h2>')


//Escrever na tela -- document.write()
//Valores com a opção do if--else--else if

// o == é diferente de = o primeiro compara e o segundo usamos pra fazer atribuição