var numero = parseInt(Math.random() * 10)
var tentativas = 3

while (tentativas > 0) {

  var chute = parseInt(prompt("Advinhe o meu número. Ele está entre 0 e 9."))

if  (numero == chute) {
  alert("Acertou!")
  break
}

else if (chute>numero) {
  tentativas = tentativas - 1
 alert("Hmm... Você errou. Tenta um número menor agora. Você tem " + tentativas + " tentativas.")
 
}
else if (chute<numero) {
      tentativas = tentativas - 1 
alert("Não, não, Não era isso. Tenta maior agora.Você tem " + tentativas +" tentativas.")  
   }

}
if (chute != numero) 
//{document.write("<h2>" + "Já era, mas vou te contar. Meu número era " + numero +'</h2>')}

{alert ("Já era, mas vou te contar. Meu número era " + numero) }
                     
                     